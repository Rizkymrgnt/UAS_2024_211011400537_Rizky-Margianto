package com.example.uas_2024_211011400604_pirmansyah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
